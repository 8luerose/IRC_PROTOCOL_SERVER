#ifndef UTIL_HPP
# define UTIL_HPP

# include "Main.hpp"
# include "Command.hpp"

bool						isSpecialChar(char c);
std::vector<std::string>	split(std::string str, char delim);

#endif
